<?php
// Copy this file to config.php and customise.
// config.php is never overwritten by upgrades; it is also excluded from git.
// Requires PHP 8.1+.

// Optional: pin the page background to a hex colour regardless of light/dark mode.
// Leave as 'null' to use the theme default.
$fixed_bg_color = 'null';

// Default active tab on page load: 'ipv4', 'ipv6', or 'vlsm'.
$default_tab = 'ipv4';

// Maximum number of subnets shown in the subnet splitter results list (1–256).
$split_max_subnets = 16;

// Form protection mode.
// Accepted values: 'none', 'honeypot', 'turnstile', 'hcaptcha', 'recaptcha_enterprise'.
// All CAPTCHA modes require the PHP cURL extension (php-curl). Without it, verification
// is skipped and a warning is emitted in the HTML source.
$form_protection = 'none';

// Cloudflare Turnstile keys (required when $form_protection = 'turnstile').
// WARNING: never expose $turnstile_secret_key in HTML or client-side code.
$turnstile_site_key   = '';
$turnstile_secret_key = '';

// hCaptcha keys (required when $form_protection = 'hcaptcha').
// WARNING: never expose $hcaptcha_secret_key in HTML or client-side code.
$hcaptcha_site_key   = '';
$hcaptcha_secret_key = '';

// Google reCAPTCHA Enterprise (required when $form_protection = 'recaptcha_enterprise').
// Create a project at https://console.cloud.google.com/security/recaptcha.
// WARNING: never expose $recaptcha_enterprise_api_key in HTML or client-side code.
$recaptcha_enterprise_site_key   = '';  // Public site key (v3 Enterprise)
$recaptcha_enterprise_api_key    = '';  // Server-side REST API key
$recaptcha_enterprise_project_id = '';  // GCP project ID (e.g. 'my-project')
$recaptcha_score_threshold       = 0.5; // 0.0–1.0; lower = more permissive

// Page title shown in the browser tab and <h1> heading.
$page_title = 'Subnet Calculator';

// Meta description and Open Graph description for share URL previews.
$page_description = 'Free online subnet calculator for IPv4 and IPv6. Calculate network address, broadcast, netmask, host range, and split subnets.';

// Show the shareable URL bar below results.
// Set to false to hide it (useful when embedded in an iframe).
$show_share_bar = true;

// Which origins may embed this page in an iframe (frame-ancestors CSP directive).
// '*' = any origin (default); "'none'" = block all embedding;
// or a space-separated list of origins, e.g. 'https://mysite.com'.
$frame_ancestors = '*';

// Canonical URL emitted in <link rel="canonical"> and og:url.
// Leave empty to auto-detect from $_SERVER (suitable for most deployments).
// Set explicitly if behind a reverse proxy that mangles REQUEST_URI or HTTP_HOST.
$canonical_url = '';

// CSP extension hooks (v3.1.1). Append space-separated origins to extend the
// default Content-Security-Policy without forking index.php. Pre-validate
// values: origins only, no quotes, commas, or newlines.
//   $csp_connect_extra — appended to connect-src (analytics beacons, fetches)
//   $csp_script_extra  — appended to script-src  (CDN-injected JS)
//   $csp_img_extra     — appended to img-src     (tracking pixels, CDN images)
// Example for a Cloudflare Zaraz + GA4 deployment:
//   $csp_connect_extra = 'https://*.cloudflareinsights.com https://*.google-analytics.com '
//                      . 'https://stats.g.doubleclick.net https://www.google.com';
//   $csp_script_extra  = 'https://static.cloudflareinsights.com';
$csp_connect_extra = '';
$csp_script_extra  = '';
$csp_img_extra     = '';

// ── Localisation (v2.4.0) ─────────────────────────────────────────────────
// BCP 47 locale tag used for locale-aware number formatting via PHP's intl extension.
// The default 'en' produces comma separators (1,234,567). Set to a different locale
// to use its conventions, e.g. 'de' → 1.234.567, 'fr' → 1 234 567.
// Requires the PHP intl extension (php-intl). Falls back to number_format() if absent.
$locale = 'en';

// ── REST API (v2.0.0) ──────────────────────────────────────────────────────
// Bearer tokens that authorise API requests.
// Empty array = open API (no auth required).
// Add one or more tokens to restrict access, e.g.: ['secret-token-1', 'tok2']
$api_tokens = [];

// Maximum API requests per IP per minute (sliding window). 0 = disabled.
$api_rate_limit_rpm = 60;

// Per-token rate limit overrides (v2.2.0).
// Map of token => requests-per-minute. Overrides $api_rate_limit_rpm for that token.
// 0 = unlimited for that token. Tokens not listed here use the global RPM.
// Example: ['secret-token-1' => 120, 'readonly-tok' => 30]
$api_rate_limit_tokens = [];

// Endpoint allowlist (v2.2.0).
// Empty array = all endpoints available (default). Non-empty = allowlist.
// Valid endpoint names: ipv4, ipv6, vlsm, vlsm6, overlap, split/ipv4,
//   split/ipv6, supernet, ula, rdns, bulk, sessions, range/ipv4, range6,
//   tree, wildcard, lookup, diff, changelog, schemas, admin.
// The meta endpoint (GET /) is always available regardless of this setting.
// Example: ['ipv4', 'ipv6'] — expose only the core calculation endpoints.
$api_allowed_endpoints = [];

// CORS Access-Control-Allow-Origin allowlist for API responses (v3.6.3, #426).
// Default ['*'] = allow all origins (back-compat with the open API). When API
// auth is configured (via $api_tokens or admin-minted SQLite keys), set this
// to a specific allowlist to scope cross-origin access:
//   $api_cors_origins = ['https://app.example.com', 'https://admin.example.com'];
// String '*' is also accepted for back-compat with pre-v3.6.3 configs.
$api_cors_origins = ['*'];

// HSTS — Strict-Transport-Security header (v3.6.3, #425). Sent on HTTPS
// responses only. max-age clamped to 0..63072000 (2 years). Set to 0 to
// disable. $hsts_preload sends "; preload" — only opt in after confirming
// HTTPS for all subdomains and a clean preload-list audit.
$hsts_max_age = 31536000;
$hsts_preload = false;

// Trusted proxies — only honor X-Forwarded-For when REMOTE_ADDR is in this
// list (v3.6.3, #427-M3). Default empty = ignore XFF entirely (safe for
// direct-exposure deploys). Examples:
//   ['127.0.0.1', '::1']                   — local reverse proxy
//   ['203.0.113.10', '203.0.113.11']       — specific known proxy IPs
$api_trusted_proxies = [];

// ── Session persistence (v2.0.0) ──────────────────────────────────────────
// Enable SQLite-backed VLSM session save/restore and short-URL sharing.
$session_enabled = false;

// Absolute path to the SQLite database file.
// Leave empty to auto-place at <docroot>/../data/sessions.sqlite.
$session_db_path = '';

// Number of days before a saved session expires and is purged.
$session_ttl_days = 30;

// ── Admin UI / API key management (v2.12.0) ──────────────────────────────
// Master switch for the /admin/ web UI and /api/v1/admin/* JSON endpoints.
// When false (default), all admin routes return 404 regardless of credentials.
$admin_ui_enabled = false;

// Admin username for the HTTP Basic Auth challenge on /admin/ pages.
$admin_user = '';

// Bcrypt hash of the admin password. Generate with:
//   php -r "echo password_hash('YOUR_PASSWORD_HERE', PASSWORD_BCRYPT) . PHP_EOL;"
// and paste the resulting $2y$10$... string here. Never commit this file.
// Operators are responsible for fronting /admin/ with TLS.
$admin_pass_hash = '';

// Optional: explicit path to the SQLite DB used for api_keys.
// When empty, the api_keys table is created in $session_db_path (when set)
// otherwise <docroot>/../data/sessions.sqlite, alongside the rate_limit table.
$apikey_db_path = '';

// ── Admin TOTP / 2FA (v3.0.0, #313) ───────────────────────────────────────
// Base32-encoded RFC 6238 TOTP secret used as the second factor for /admin/
// login. Leave empty (default) to disable TOTP and authenticate with Basic
// Auth alone. Generate via the first-run admin wizard at /admin/setup.php,
// or from the docroot:
//   php -r 'require "includes/functions-admin-totp.php"; echo admin_totp_generate_secret(), PHP_EOL;'
// (PHP core has no built-in base32 helper — admin_totp_generate_secret()
// in functions-admin-totp.php wraps random_bytes(20) with the project's
// RFC 4648 base32 encoder.) Pair the resulting otpauth:// URI with Google
// Authenticator / 1Password / Authy. Treat this value like a password —
// never commit, rotate if leaked.
$admin_totp_secret = '';

// ── Audit log retention (v3.0.0, #306) ────────────────────────────────────
// Days of /admin/ audit-log rows to retain. 0 = never purge. Older rows are
// removed lazily on each audit write according to $admin_audit_purge_strategy.
$admin_audit_retention_days = 90;

// Trust the X-Forwarded-For header when recording the requester IP in audit
// rows. Only enable behind a trusted reverse proxy that strips/replaces XFF —
// otherwise clients can spoof their logged IP.
$admin_audit_trust_xff = false;

// How aggressively audit_log() purges old rows.
//   'inline'  — every write also runs a DELETE for expired rows. Predictable
//               but adds a few ms to each admin action.
//   'sampled' — each write has $admin_audit_purge_sample_rate probability
//               of running the DELETE. Default 0.1% (1 in 1000 writes pays
//               the cost). Cheapest in steady state.
//   'cron'    — never purge inline; expects an external cron job to run
//               `php bin/sc-audit-purge.php` on a schedule.
$admin_audit_purge_strategy    = 'sampled';
$admin_audit_purge_sample_rate = 0.001;

// ── Tree-editor preset library (v3.1.0, #323) ─────────────────────────────
// Absolute path to a directory of `*.json` preset files for the tree-editor
// "Apply Template" button. Empty = use the bundled
// Subnet-Calculator/data/tree-presets/ directory. A non-existent override
// falls back to the bundled location (with a single error_log warning).
$tree_presets_dir = '';
