<?php
/**
 * PHP built-in server router — replicates the .htaccess rules for Docker/dev use.
 * Not deployed to production (Apache/.htaccess handles routing there).
 */

declare(strict_types=1);

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '/';

// Block sensitive files (mirrors .htaccess <Files> and <FilesMatch> rules)
$basename = basename($uri);
if (
    $basename === 'config.php'
    || $basename === 'config.php.example'
    || $basename === 'helpers.php'
    || preg_match('/\.(sqlite|tar\.gz|tar|gz|zip)$/', $basename)
) {
    http_response_code(403);
    echo '403 Forbidden';
    return true;
}

// Block protected directories
$blocked_prefixes = ['/includes/', '/templates/', '/data/', '/api/v1/handlers/'];
foreach ($blocked_prefixes as $prefix) {
    if (str_starts_with($uri, $prefix)) {
        http_response_code(403);
        echo '403 Forbidden';
        return true;
    }
}

// Route all /api/v1/* requests through the API front controller
if (str_starts_with($uri, '/api/v1/') || $uri === '/api/v1') {
    require __DIR__ . '/api/v1/index.php';
    return true;
}

// Serve real files (CSS, JS, images, fonts, openapi.yaml, etc.)
$file = __DIR__ . $uri;
if ($uri !== '/' && file_exists($file) && is_file($file)) {
    return false; // let PHP built-in server handle static files
}

// All other requests → main app
require __DIR__ . '/index.php';
return true;
